/* $Id: get.c,v 1.1 2002/10/06 03:25:50 adi Exp $ */

/* 
 * Copyright (C) 2002  Adi Linden <adi@adis.on.ca>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

/* 
 * get.c  Utilitiy functions required by rsch.c
 */

#include <string.h>
#include <ctype.h>
#include "rcsh.h"

/* 
 * strip_path - Seperate program name from path components
 *
 * Returns pointer to the program without leading path components.
 */
char *strip_path(char *cmd)
{
    char *prg;
    
    /* Strip leading whitespace */
    while (*cmd && isspace(*cmd)) {
        cmd++;
    }

    prg = cmd;

    /* Strip leading path information */
    while (*cmd) {
        if (*cmd == '/') {
            prg = cmd + 1;
        }
        cmd++;
    }

    return prg;
}

/*
 * get_prg - Seperate program name from path components and arguments
 *
 * Returns pointer to the program name with out leading path or 
 * trailing arguments. 
 *
 * This function may modify the contents of "cmd", in particular, 
 * a '\0' may be inserted to seperate program name from arguments. 
 * If arguments are needed, call get_arg first. This is similar to 
 * glibc's basename
 */
char *get_prg(char *cmd)
{
    char *a;

    /* Strip leading path components */
    cmd = strip_path(cmd);

    /* Insert NULL character behind command name */
    a = strpbrk(cmd, " \t");
    if (a) {
        *a = '\0';
    }
    
    return cmd;
}

/*
 * get_arg - Seperate arguments from path and program name
 *
 * Returns pointer to the arguments without leading path and program
 * components, or NULL if no arguments found. This functions does not 
 * alter the contents of cmd.
 */
char *get_arg(char *cmd)
{
    char *a;

    /* Strip leading path components */
    cmd = strip_path(cmd);
    
    /* Find first non space after command */
    a = strpbrk(cmd, " \t");
    if (a) {
        while (*a) {
            if (*a != ' ' && *a != '\t') {
                return a;
            }
            a++;
        }
    }

    return NULL;
}
