/* $Id: rcsh.c,v 1.8 2002/10/06 03:31:31 adi Exp $ */

/* 
 * Copyright (C) 2002  Adi Linden <adi@adis.on.ca>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

/* 
 * rcsh.c  Restricted command shell. Useful as login shell to
 *         severely restrict the available commands.
 *
 *         Based on the sources of sendmail 8.10.2 smrsh.
 */

#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <syslog.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "rcsh.h"

/* Default hostname */
#define HOSTNAME        "unknown"

/* Characters disallowed in the shell "-c" argument */
#define BADCHARS        "<|>^();&`$\r\n"

/* Defaultpath to the real shell */
#ifndef EXECSH
#define EXECSH          "/bin/sh"
#endif

/* Default path for executed command */
#ifndef EXECPATH
#define EXECPATH        "/bin:/usr/bin"
#endif

/* Directory in which all commands must reside */
#ifndef CMDDIR
#define CMDDIR          "/etc/rcsh"
#endif

char *noexec  = 
    "This is a restricted Shell Account.\n"
    "You cannot execute anything here.\n";
                
char *noshell = 
    "This is not a Shell Account.\n"
    "You cannot execute anything here.\n";

char *strip_path(char *);
char *get_prg(char *);
char *get_arg(char *);
    
/* Main program */
int main(int argc, char *argv[])
{
    char hostname[80];      /* hostname */
    char newcmd[1000];      /* the new command and command args */
    char pathbuf[255];      /* new path for execle */
    char *newenv[2];        /* array of pointers for execle */
    char *badchars = BADCHARS;
    char *prg;              /* what we were executed as */
    char *cmd;              /* the command and args passed to us via -c */
    char *arg;              /* the args passed to the the command */
    char *a;
    int uid;                /* the uid that started us */
    int i;

    /* New environment */
    (void) strcpy(pathbuf, "PATH=");
    (void) strcat(pathbuf, EXECPATH);
    newenv[0] = pathbuf;
    newenv[1] = NULL;
    
    /* Our hostname */
    if (gethostname(hostname, sizeof hostname - 1) != 0) {
        strcpy(hostname, HOSTNAME);
    } 
    
    /* What we were called as */
    prg = get_prg(argv[0]);

    /* The uid that executed us */
    uid = getuid();
    
    openlog(prg, 0, LOG_USER);

    /* 
     * noshell - Just return an error message 
     *
     * If we were executes as noshell it is implied that no shell account
     * is available period. Just send a message saying so.
     */
    if (strcmp(prg, "noshell") == 0) {
        fprintf(stderr, "\nWelcome to %s!\n\n%s\n", hostname, noshell);
        syslog(LOG_ERR, "uid %i: attempted noshell command", uid);
        closelog();
        exit(1);
    }

    /* No interactive operation */
    if (argc != 3 || strcmp(argv[1], "-c") != 0) {
        fprintf(stderr, "\nWelcome to %s\n\n%s\n", hostname, noexec);
        syslog(LOG_ERR, "uid %i: attempted interactive shell", uid);
        closelog();
        exit(1);
    }

    cmd = argv[2];
    
    /* Check command line length */
    i = strlen(cmd);
    if (i > (sizeof newcmd - sizeof CMDDIR - 2)) {
        fprintf(stderr, "%.20s: command too long, %i chars.\n", prg, i);
        syslog(LOG_ERR, "uid %i: attempted command with %i characters", uid, i);
        closelog();
        exit(1);
    }

    /* Check for non-ascii characters */
    a = cmd;
    while (*a) {
        if (isascii(*a) == 0) {
            fprintf(stderr, "%.20s: command conatains non-ascii chars.\n", prg);
            syslog(LOG_ERR, 
                   "uid %i: attempted command with non-ascii characters", uid);
            closelog();
            exit(1);
        }
        a++;
    }

    /* Check for forbidden (badchars) characters */
    a = cmd;
    if (strpbrk(cmd, badchars)) {
        fprintf(stderr, "%.20s: command contains forbidden chars.\n", prg);
        syslog(LOG_ERR, 
                "uid %i: attempted command with forbidden characters.", uid);
        closelog();
        exit(1);
    }

    /* Split command into program and argument(s) */
    arg = get_arg(cmd);
    cmd = get_prg(cmd);
    if (cmd && strlen(cmd) < 1) {
        fprintf(stderr, "%.20s: no command to execute.\n", prg);
        syslog(LOG_ERR, "uid %i: no command to execute.", uid);
        closelog();
        exit(1);
    }

    /* Build new command line */
    (void) strcpy(newcmd, CMDDIR);
    (void) strcat(newcmd, "/");
    (void) strcat(newcmd, prg);
    (void) strcat(newcmd, "/");
    (void) strcat(newcmd, cmd);

    /* See if we can execute the command */
    if (access(newcmd, X_OK) < 0) {
        fprintf(stderr, "%s: execution of %.24s is forbidden.\n", prg, cmd);
        syslog(LOG_ERR, "uid %i: attempted to use %.24s.", uid, cmd);
        closelog();
        exit(1);
    }

    /* Add args to  command line */
    if (arg && strlen(arg) > 0) {
        (void) strcat(newcmd, " ");
        (void) strcat(newcmd, arg);
    }

    /* Execute command line */
    syslog(LOG_INFO, "uid %i: executed '%.24s'.", uid, newcmd);
    closelog();
    (void) execle(EXECSH, EXECSH, "-c", newcmd, NULL, newenv);
    
    /* We only get here if an error occured executing */
    syslog(LOG_CRIT, "Cannot exec %s", EXECSH);
    exit (1);
    return 0;
}

